<template>
  <div class="x-bar">
    <div :id="id" :option="option"></div>
  </div>
</template>

<script>
	import HighCharts from 'highcharts'
	import bus from '@/assets/scripts/eventBus'
	export default {
	  data(){
	  	return {
	  		chart: null
	  	}
	  },
	  // 验证类型
	  props: {
	    id: {
	      type: String
	    },
	    option: {
	      type: Object
	    },
	    data: {
	      type: Array
	    }
	  },
	  mounted() {
	  	// this.option.series = [{}];
	    this.chart = HighCharts.chart(this.id,this.option);
	    let self = this
	    bus.$on("toggleFullWidth", function(msg){
	    	setTimeout(function(){
	    		self.chart.reflow()
	    	},410)
	    });
	    bus.$on("updateChart", function(msg){
	    	self.redraw();
	    });
	  },
	  methods:{
	  	redraw: function() {
	  		console.log("redraw");
	  		console.log(this.data);
	  		this.chart.series[0].setData(this.data);
	  		// this.chart.redraw();
	  		// this.chart = HighCharts.chart(this.id,this.option);
	  	}
	  }
	}
</script>

<style type="text/css">
	
</style>